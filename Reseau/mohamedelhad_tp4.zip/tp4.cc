//MOHAMED EL-HAD Mellany

#include <iostream>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include "sock.h"
#include <stdio.h>

using namespace std;

int main(int argc, char* argv[], char* env[])
{
  //int test1 = 10000;
  /* Allocation de la BR  */
  Sock breLoc(SOCK_DGRAM, (short)9001, 0);
  int descripteur;
  
  /* Recuperation du descripteur  */
  if(breLoc.good())
    descripteur = breLoc.getsDesc();
  else
  {
    cout << "pb BR local" << endl;
    return 1;
  }
  struct sockaddr_in name; /*on passe par cette structure car sockaddr n'a pas d'attribut sin_port, on la castera pour la faire passer en parametre de la fonction getsockname */
  socklen_t namelen;
  namelen = sizeof(name); //recuperation de la taille de la name (struct sockaddr_in)
  //test1 = getsockname(s, (struct sockaddr *) &name, &namelen);
  //cout << "getsockname = " << test1 << endl;
  if(getsockname(descripteur, (struct sockaddr *) &name, &namelen) != -1) //on cast name en struct sockaddr * pour avoir le bon type de parametre
  {
    cout << "Port : " << (int) ntohs(name.sin_port) << endl;
  }
  else
  {
    perror("error"); //affiche l'erreur s'il y'en a.
  }
  return 0;
}
